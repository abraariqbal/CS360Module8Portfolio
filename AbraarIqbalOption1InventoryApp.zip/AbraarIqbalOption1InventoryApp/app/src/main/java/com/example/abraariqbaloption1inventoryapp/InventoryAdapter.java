package com.example.abraariqbaloption1inventoryapp;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.content.ContextCompat;

import java.util.List;
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ItemViewHolder> {
    private final List<InventoryItem> items;
    private final DatabaseHelper databaseHelper;
    private final int userId;
    public InventoryAdapter(List<InventoryItem> items, DatabaseHelper databaseHelper, int userId) {
        this.items = items;
        this.databaseHelper = databaseHelper;
        this.userId = userId;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.itemName.setText(item.getName());
        holder.quantityText.setText(String.valueOf(item.getQuantity()));

        // Increase quantity by one
        holder.increaseButton.setOnClickListener(v -> {
            int newQuantity = item.getQuantity() + 1;
            updateQuantity(holder, item, newQuantity);
        });

        // Decrease quantity by one, but never below zero
        holder.decreaseButton.setOnClickListener(v -> {
            int newQuantity = Math.max(0, item.getQuantity() - 1);
            updateQuantity(holder, item, newQuantity);
        });

        // Save quantity after the user is done editing
        holder.quantityText.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                try {
                    int newQuantity = Integer.parseInt(
                            holder.quantityText.getText().toString()
                    );
                    if (newQuantity >= 0 && newQuantity != item.getQuantity()) {
                        updateQuantity(holder, item, newQuantity);
                    } else {
                        holder.quantityText.setText(String.valueOf(item.getQuantity()));
                    }
                } catch (NumberFormatException e) {
                    holder.quantityText.setText(String.valueOf(item.getQuantity()));
                }
            }
        });

        // Delete the selected inventory item
        holder.deleteButton.setOnClickListener(v -> {
            if (databaseHelper.deleteItem(item.getId(), userId)) {
                int currentPosition = holder.getBindingAdapterPosition();
                if (currentPosition != RecyclerView.NO_POSITION) {
                    items.remove(currentPosition);
                    notifyItemRemoved(currentPosition);
                }
                Toast.makeText(holder.itemView.getContext(),
                        "Item deleted", Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void updateQuantity(ItemViewHolder holder, InventoryItem item, int quantity) {
        // Remember the previous quantity before updating it
        int previousQuantity = item.getQuantity();
        if (databaseHelper.updateItemQuantity(item.getId(), userId, quantity)) {

            // Update the Java object and displayed quantity
            item.setQuantity(quantity);
            holder.quantityText.setText(String.valueOf(quantity));

            // Send an alert when the quantity changes from more than zero to zero
            if (previousQuantity > 0 && quantity == 0) {
                sendLowStockAlert(holder.itemView.getContext(), item.getName(), userId);
            }
        } else {
            Toast.makeText(holder.itemView.getContext(),
                    "Unable to update quantity", Toast.LENGTH_SHORT).show();
        }
    }

    // Send SMS when inventory item reaches zero
    private void sendLowStockAlert(Context context, String itemName, int userId) {
        // Get the user's saved SMS settings
        SharedPreferences preferences =
                context.getSharedPreferences("SMSSettings_" + userId, Context.MODE_PRIVATE);
        boolean smsEnabled = preferences.getBoolean("sms_enabled", false);
        String phoneNumber = preferences.getString("phone_number", "").trim();

        // DO NOT send SMS if notifications are disabled
        if (!smsEnabled) {
            return;
        }

        // Make sure a phone number has been saved
        if (phoneNumber.isEmpty()) {
            Toast.makeText(context, "SMS alert not sent: No phone number saved",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Check whether Android has granted SMS permission
        if (ContextCompat.checkSelfPermission(
                context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(context, "SMS alert not sent: Permission denied",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        // Create the SMS message
        String message = "Inventory Alert: " + itemName
                + " is now out of stock (Quantity = 0).";

        // Try to send the SMS
        try {
            SmsManager smsManager = context.getSystemService(SmsManager.class);
            if (smsManager != null) {
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            } else {
                Toast.makeText(context, "SMS service unavailable",
                        Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(context, "Unable to send SMS alert",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView itemName;
        EditText quantityText;
        Button increaseButton, decreaseButton;
        ImageButton deleteButton;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            quantityText = itemView.findViewById(R.id.quantityText);
            increaseButton = itemView.findViewById(R.id.increaseButton);
            decreaseButton = itemView.findViewById(R.id.decreaseButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}

