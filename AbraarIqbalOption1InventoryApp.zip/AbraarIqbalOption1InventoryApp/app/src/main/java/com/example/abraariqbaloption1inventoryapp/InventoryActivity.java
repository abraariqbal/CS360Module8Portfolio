package com.example.abraariqbaloption1inventoryapp;

import android.os.Bundle;
import android.widget.ImageButton;
import android.content.Intent;
import android.database.Cursor;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class InventoryActivity extends AppCompatActivity {
    private RecyclerView inventoryRecyclerView;
    private DatabaseHelper databaseHelper;
    private InventoryAdapter inventoryAdapter;
    private final List<InventoryItem> inventoryItems = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseHelper = new DatabaseHelper(this);

        inventoryRecyclerView = findViewById(R.id.inventoryRecyclerView);
        ExtendedFloatingActionButton addItemButton = findViewById(R.id.addItemButton);
        ImageButton settingsButton = findViewById(R.id.settingsButton);

        // Display inventory records in vertical list
        inventoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        int userId = getIntent().getIntExtra("USER_ID", -1);
        inventoryAdapter = new InventoryAdapter(inventoryItems, databaseHelper, userId);
        inventoryRecyclerView.setAdapter(inventoryAdapter);

        // Open the Add Item screen
        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, AddItemActivity.class);
            intent.putExtra("USER_ID", getIntent().getIntExtra("USER_ID", -1));
            startActivity(intent);
        });

        // Open SMS notification settings screen
        settingsButton.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, smsSettingActivity.class);
            intent.putExtra("USER_ID", getIntent().getIntExtra("USER_ID", -1));
            startActivity(intent);
        });
    }

    // Refresh inventory whenever this screen becomes visible
    @Override
    protected void onResume() {
        super.onResume();
        loadInventory();
    }
    private void loadInventory() {
        int userId = getIntent().getIntExtra("USER_ID", -1);
        inventoryItems.clear();
        try (Cursor cursor = databaseHelper.getAllItems(userId)) {
            int idColumn = cursor.getColumnIndexOrThrow("id");
            int nameColumn = cursor.getColumnIndexOrThrow("item_name");
            int quantityColumn = cursor.getColumnIndexOrThrow("quantity");
            while (cursor.moveToNext()) {
                int id = cursor.getInt(idColumn);
                String name = cursor.getString(nameColumn);
                int quantity = cursor.getInt(quantityColumn);
                inventoryItems.add(new InventoryItem(id, name, quantity));
            }
        }
        inventoryAdapter.notifyDataSetChanged();
    }
}